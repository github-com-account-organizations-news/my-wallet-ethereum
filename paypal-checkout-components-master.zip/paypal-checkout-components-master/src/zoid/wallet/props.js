/* @flow */

export type WalletProps = {|
    
|};
