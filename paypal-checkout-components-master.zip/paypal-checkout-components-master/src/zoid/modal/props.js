/* @flow */

export type ModalProps = {|
    
|};
